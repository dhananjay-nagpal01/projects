#!/usr/bin/env python
# coding: utf-8

# # PUBG WEAPON DATA ANALYSIS

# In[2]:


import pandas as pd
import numpy as nm
import matplotlib.pyplot as plt7
import seaborn as sns


# In[3]:


data=pd.read_csv(r"C:\Users\HP\Documents\Python Scripts\pubg-weapon-stats.csv")


# # DATASET

# In[4]:


data.head(10)


# In[5]:


data.tail(10)


# # DATA CLEANING

# In[6]:


data.isnull().sum()


# In[7]:


df=pd.DataFrame(data)


# In[8]:


df.dropna()


# # RENAMING COLUMNS

# In[9]:


df.rename(columns={'Rate of Fire':'Rate_of_Fire'},inplace=True);
df.rename(columns={'Bullet Speed':'Bullet_Speed'},inplace=True);
df.rename(columns={'Weapon Name':'Weapon_Name'},inplace=True);


# In[10]:


df.info()


# # QUESTIONS & ANSWERS

# In[11]:


#Merging two columns using group by?
weapons_damage_level = df.groupby('Weapon_Name')['BDMG_1'].sum()
weapons_damage_level.head(10)


# In[12]:


weapons_damage_level_1 = df.groupby('Weapon_Name')['HDMG_1'].sum()
weapons_damage_level_1.head(10)


# In[13]:


#Depicting Relations b/w weapons and BDMG_1?
plt.figure(figsize=(38,15))
df.sort_values(by='Weapon_Name').head(20)
sns.barplot(x=weapons_damage_level.index, y=weapons_damage_level, color = 'Green')
        
plt.title('Depicting Relations b/w weapons and BDMG_1',fontsize=32,weight='bold')
plt.xlabel('Weapon Name')
plt.ylabel('BDMG')


# In[14]:


#Depicting Relations b/w weapons and HDMG_1?
plt.figure(figsize=(38,15))
df.sort_values(by='Weapon_Name').head(20)
sns.barplot(x=weapons_damage_level_1.index, y=weapons_damage_level_1, color = 'black')
plt.title('Depicting Relations b/w weapons and HDMG_1',fontsize=32,weight='bold')
plt.xlabel('Weapon Name')
plt.ylabel('HDMG')


# In[16]:


# Plotting facegrid using seaborn
g=sns.FacetGrid(df,col='Weapon Type',sharey=False,palette='black')
g.map(sns.histplot,"Damage")
g.set_axis_labels('Damage')


# In[19]:


Classification_weapons=df.groupby('Weapon_Name')['Rate_of_Fire'].sum()
Classification_weapons.head(20)


# In[20]:


#depicting relations b/w bullet speed and rate of firing?
plt.rcParams['figure.figsize'] = (17,9)
plt.title('Relation b/w Bullet Speed and rate of fire',weight='bold',fontsize='28')
sns.scatterplot(x= df.Bullet_Speed, y =df.Rate_of_Fire, hue = df.Rate_of_Fire, s=300);
plt.legend(loc = 'upper left' , fontsize = '10')
plt.xlabel('Bullet_Speed')
plt.ylabel('Rate of Fire')


# In[21]:


df.rename(columns={'Damage per Second':'Damage_per_Second'},inplace=True);
df.rename(columns={'Weapon Type':'Weapon_Type'},inplace=True);


# In[22]:


# Distplot using seaborn
sns.set_style('whitegrid')
plt.figure(figsize=(40,15))
plt.title("Distribution plot Depicting the speed of Bullet according to Guns ",weight='bold',fontsize=30)
sns.distplot(df['Bullet_Speed'], hist=True ,kde = True, color ='black', bins = 30,rug=True)


# In[23]:


df['Weapon_Name_with_Type']=df['Weapon_Name']+df['Weapon_Type']


# In[24]:


x=df['Weapon_Name_with_Type']
y=df['Magazine Capacity']
sns.set_style('darkgrid')
plt.figure(figsize=(15,9))
plt.hlines(y=x,xmin=0,xmax=y,color='red')
plt.plot(y,x,'o',color='black')
plt.title("Lollipop Plot Depicting the weapon with highest magazine capacity ",weight='bold',fontsize='20')
plt.show()


# In[25]:


Classification_weapons = df.groupby('Weapon_Name')['Weapon_Type'].sum()
Classification_weapons.head(10)


# In[26]:


Classification_weapons= df.Weapon_Type.value_counts().sort_values(ascending=False).head(10)
Classification_weapons


# In[27]:


# Classification of weapon types using pie chart
plt.figure(figsize=(17,9))
Classification_weapons.plot.pie(autopct = '%1.1f%%')
plt.title("Claasification of weapon Types",fontsize=20)


# In[28]:


import numpy as np
cor = df.corr(method = "pearson")
f , ax = plt.subplots(figsize = (15,9))
sns.heatmap(cor, mask = np.zeros_like(cor, dtype=bool),
           cmap="crest", ax =ax)
plt.title("Heat Map Analysis ",fontsize='20',style='italic',weight='bold')


# In[29]:


a_list=data[['Rate_of_Fire']].values.tolist()
a_list


# # TRY AND EXCEPT STATEMENTS

# In[43]:


import sys

df['Rate_of_Fire']
for column in df[['Rate_of_Fire']]:
    for entry in df['Rate_of_Fire']:
        try:
            print("The entry is", entry)
            r = 1/float(entry)
            break
        except:
            print("Oops!", sys.exc_info()[0], "occurred.")
            print("Next entry.")
            print()
    print("The reciprocal of", entry, "is", r)


# # FRAMING CLASSES

# In[31]:


class PUBG:
        def weapons_damage(bbbbbbbbbbbbbbbq2 ,data):
             print(data.groupby('Weapon_Name')['Damage Per Second'].sum().head(20))
        plt.figure(figsize=(38,15))
        df.sort_values(by='Weapon_Name')
        plt.title('Damage According To Weapons',fontsize='30',weight='bold')
        sns.barplot(x= "Weapon_Name",y="Damage",data=df, palette=['Black','Red'])
        
obj1 = PUBG()
obj1.weapons_damage(data)
#     def __init__(Weapons):
#         Weapons.Weapon Name=""
#         Weapons.Weapon Type=""
#         Weapons.Damage=""
        
#     def do_work(Weapons):
#         if Weapon.Weapons Name=="AWM":
#             print(Weapons.Weapon Type,"Sniper Rifle")
#             print(Weapons.Damage,"105")
#         elif print(Weapons.Weapon Type,"")
#             print(Weapons.Damage,"") 

        


# In[ ]:





# In[ ]:




