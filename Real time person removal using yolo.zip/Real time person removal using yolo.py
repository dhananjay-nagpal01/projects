#!/usr/bin/env python
# coding: utf-8

# In[1]:


import cv2
import time
import numpy as np


# In[2]:


# writing the output to a video
fourcc=cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter(
    'output_hog.avi',
    fourcc,
    15.,
    (640,480))


# In[3]:


import cv2
import numpy as np

cap= cv2.VideoCapture(0)
whT=320
confTreshold=.5
nmsThreshold=.3
classFile = 'coconames.txt'

classNames=[]

with open (classFile,'rt') as f:
   classNames=f.read().rstrip('\n').split('\n')


modelConfiguration='yolov3.cfg'
modelWeights='yolov3.weights'

net= cv2.dnn.readNetFromDarknet(modelConfiguration,modelWeights)

net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)

net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)

def findObjects(outputs,img):
    hT,wT,cT= img.shape
    bbox=[]
    classIds=[]
    confs=[]
    
    for output in outputs:
        for det in output:
            scores=det[5:]
            classId= np.argmax(scores)
            confidence= scores[classId]
            if confidence > confTreshold:
                w,h= int(det[2]*wT), int(det[3]*hT)
                x,y= int((det[0]*wT)- w/2),int((det[1]*hT)- h/2)
                bbox.append([x,y,w,h])
                classIds.append(classId)
                confs.append(float(confidence))
    #print(len(bbox))
    indices=cv2.dnn.NMSBoxes(bbox,confs,confTreshold,nmsThreshold)
    original = img.copy()
    rectangle = img.copy()
    
    
    for i in indices:
        i=i
        box=bbox[i]
        x,y,w,h=box[0],box[1],box[2],box[3]
        crop_img = first_frame[y:y + h, x:x + w]
        img[y:y + h, x:x + w] = crop_img
       
        # could also write
        # frame[y:y + h, x:x + w] = first_frame[y:y + h, x:x + w]

        # for debugging show bounding rectangle
        cv2.rectangle(rectangle, (x, y), (x+w, y+h), (0, 255, 0), 2)
    image = cv2.rotate(img, cv2.ROTATE_180)  
    cv2.imshow("Dhananjay",image)
    cv2.imshow('Danny New Frame', img)
    cv2.imshow('Begining Frame', first_frame)
    cv2.imshow('Clean Frame', original)
    cv2.imshow('Detection Frame', rectangle)

    out.write(img)

    
        #cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,255),2)
        #cv2.putText(img,f'{classNames[classIds[i]].upper()} {int(confs[i]*100)}%',(x,y-10),cv2.FONT_HERSHEY_SIMPLEX,0.6,(255,0,255),2)
            

time.sleep(3)
n_frame = 0
while True:
    sucess, img = cap.read()
    img = cv2.rotate(img,rotateCode = 1)
    n_frame += 1

    if n_frame == 2:
        img = cv2.resize(img, (640, 480))
        img = cv2.rotate(img,rotateCode = 1)
        first_frame = img.copy()
        first_frame = cv2.rotate(first_frame, rotateCode =1)
        break
        
        
_, img = cap.read()
img= cv2.rotate(img,rotateCode = 1)
img = cv2.resize(img, (640, 480))


while True:
    
     sucess,img=cap.read()
    
        
        
     blob=  cv2.dnn.blobFromImage(img,1/255,(whT,whT),[0,0,0],1,crop=False)
     net.setInput(blob)
     layerNames=net.getLayerNames()
     
     #print(layerNames)
     outputNames=[layerNames[i-1] for i in  net.getUnconnectedOutLayers()]
     #print(net.getUnconnectedOutLayers())
     print(outputNames)
     outputs= net.forward(outputNames)
     #print(outputs[0].shape)
     #print(outputs[1].shape)
     #print(outputs[2].shape)
     
     findObjects(outputs,img)
     if cv2.waitKey(1) & 0xFF == ord('q'):
        break
     
     
     cv2.imshow('image',img)
     
    


# In[ ]:


#print(classNames)
#print(len(classNames))


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




